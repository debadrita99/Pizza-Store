package com.service;

public interface NotificationService {
	public void notifyUser(Long userId, String message);
}
