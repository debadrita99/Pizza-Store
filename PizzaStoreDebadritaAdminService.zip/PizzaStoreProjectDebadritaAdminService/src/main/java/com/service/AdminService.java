package com.service;

import com.entity.Admin;

public interface AdminService {
	public Admin createAdmin(Admin admin); 
	public Admin getAdminById(Long adminid);
	public Admin updateAdmin(Admin admin);
	public void deleteAdmin(Long adminid);
}
