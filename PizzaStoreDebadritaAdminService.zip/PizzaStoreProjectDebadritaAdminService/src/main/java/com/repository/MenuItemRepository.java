package com.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.entity.MenuItem;

public interface MenuItemRepository extends JpaRepository<MenuItem,Long> {

}
