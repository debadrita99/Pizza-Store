package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.entity.MenuItem;
import com.service.MenuItemService;

@Controller
public class AdminViewController {

    @Autowired
    private MenuItemService menuItemService;

    @RequestMapping("/wel")
    public String welcome() {
        return "index";
    }

    @RequestMapping("/welcome")
    public String welcome1() {
        return "welcome";
    }

    @GetMapping("/login")
    public String loginPage() {
        return "login"; // This should match the JSP file name without the .jsp extension
    }

    @PostMapping("/login")
    public String login(@RequestParam("username") String username,
                        @RequestParam("password") String password,
                        Model model) {
        // Handle login logic here
        // Assuming login is successful, add the success message to the model
        model.addAttribute("message", "Successfully logged in!");
        return "home"; // Return to the home page after login, passing the model
    }

    @GetMapping("/home")
    public String homePage(Model model) {
        // Fetch all menu items and add them to the model
        model.addAttribute("menuItems", menuItemService.getAllMenuItems());
        return "home"; // This should match the JSP file name for the home page
    }

    @PostMapping("/addMenuItem")
    public String addMenuItem(@RequestParam("name") String name,
                              @RequestParam("price") double price,
                              @RequestParam("description") String description,
                              RedirectAttributes redirectAttributes) {
        // Create a new MenuItem object
        MenuItem menuItem = new MenuItem();
        menuItem.setName(name);
        menuItem.setPrice(price);
        menuItem.setDescription(description);
        
        // Add the MenuItem to the database
        menuItemService.addMenuItem(menuItem);
        
        // Add success message and redirect to /home
        redirectAttributes.addFlashAttribute("message", "Menu item added successfully!");
        return "redirect:/home";
    }
}



  /*
   * @PostMapping("/register") public String
   * registerAdmin(@ModelAttribute("admin") Admin admin, Model model) { // Add
   * some logging System.out.println("Registering Admin: " + admin);
   * 
   * // Save the admin using AdminService Admin registeredAdmin =
   * adminService.saveAdmin(admin);
   * 
   * // Add success message or other details to model model.addAttribute("admin",
   * registeredAdmin); return "registrationSuccessAdmin"; }
   */