package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestBody;

import com.entity.Admin;
import com.service.AdminServiceImpl;

@RestController
//@ResponseBody
@RequestMapping("/api/admin")
public class AdminController {
	@Autowired
	private AdminServiceImpl adminService;
  @PostMapping("/addadmin")
  public Admin createAdmin(@RequestBody Admin admin) {
      return adminService.createAdmin(admin);
  }

  @GetMapping("/getadmin/{adminid}")
  public Admin getAdminById(@PathVariable Long adminid) {
      return adminService.getAdminById(adminid);
  }

  @PutMapping("/updateadmin")
  public Admin updateAdmin(@RequestBody Admin admin) {
      return adminService.updateAdmin(admin);
  }

  @DeleteMapping("/delete/{adminid}")
  public void deleteAdmin(@PathVariable Long adminid) {
      adminService.deleteAdmin(adminid);
  }
}
