package com.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
//import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.entity.MenuItem;
import com.service.MenuItemService;

@RestController

@RequestMapping("/api/admin")
public class MenuItemController {
	@Autowired
	private MenuItemService adminservice;
	@GetMapping("/menu")
	public String menuPage() {
	return "menu"; // Returns /WEB-INF/views/menu.jsp
	}
	@PostMapping("/menu/add")
	public ResponseEntity<MenuItem>addmenuitem(@RequestBody MenuItem menuitem){
		MenuItem createitem=adminservice.addMenuItem(menuitem);
		return new ResponseEntity<>(createitem,HttpStatus.CREATED);
	}
	@PutMapping("/menu/update")
	public ResponseEntity<MenuItem>updatemenuitem(@RequestBody MenuItem menuitem){
		MenuItem updateditem=adminservice.updateMenuItem(menuitem);
		return new ResponseEntity<>(updateditem,HttpStatus.OK);
	}
	
	@DeleteMapping("/menu/delete/{itemid}")
	public ResponseEntity<Void>deletemenuitem(@PathVariable Long itemid){
		adminservice.deleteMenuItem(itemid);
		return new ResponseEntity<>(HttpStatus.OK);
	}
	@GetMapping("/menu/get/{itemid}")
	public ResponseEntity<MenuItem> getmenuitembyId(@PathVariable Long itemid) {
	    Optional<MenuItem> item = adminservice.getMenuItembyId(itemid);
	    if (item.isPresent()) {
	        return new ResponseEntity<>(item.get(), HttpStatus.OK);
	    } else {
	        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	    }
	}

	@GetMapping("/menu/getitems")
	public ResponseEntity<List<MenuItem>>getmenuitems(){
	List<MenuItem>items=adminservice.getAllMenuItems();
		return new ResponseEntity<>(items,HttpStatus.OK);
	}
}
