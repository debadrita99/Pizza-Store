package com.entity;

public class User {

}
