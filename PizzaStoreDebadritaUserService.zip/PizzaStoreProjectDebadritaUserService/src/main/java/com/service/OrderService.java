package com.service;

import com.entity.Order;
import java.util.List;
import java.util.Optional;

public interface OrderService {
	public Order saveOrder(Order order);
	public Optional<Order> findOrderById(Long orderid);
	public List<Order> getAllOrders();
	public void deleteOrder(Long orderid);
}
