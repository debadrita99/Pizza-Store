package com.service;

import com.entity.User;
import java.util.Optional;

public interface UserService {

    // Method to register a new user
    User registerCustomer(User user);

    // Method to find a user by ID
    Optional<User> findCustomerById(Long id);

    // Method to delete a user by ID
    void deleteCustomer(Long id);

    // Method to authenticate a user by username and password
    boolean authenticate(String username, String password);
}

    
/* // Method to generate a bill for a specific order
    public Bill generateBillForOrder(Long orderId) {
        // Build the URL for the admin service to generate the bill
        String url = adminServiceUrl + "/api/admin/bills/generate/" + orderId;

        // Call the admin service to generate the bill
        Bill bill = restTemplate.postForObject(url, null, Bill.class);

        // Handle cases where the bill is not generated (e.g., order not found)
        if (bill == null) {
            throw new IllegalArgumentException("Failed to generate bill for order ID: " + orderId);
        }

        return bill;
    }
*/
    // Uncomment and implement this method if authentication is needed
    /*
    public boolean authenticate(String username, String password) {
        Optional<User> userOpt = userRepository.findByUsername(username);
        return userOpt.isPresent() && userOpt.get().getPassword().equals(password);
    }
    */
    
   /* public boolean authenticate(String username, String password) {
        Optional<User> userOpt = userRepository.findByUsername(username);
        return userOpt.isPresent() && userOpt.get().getPassword().equals(password);
    }*/

