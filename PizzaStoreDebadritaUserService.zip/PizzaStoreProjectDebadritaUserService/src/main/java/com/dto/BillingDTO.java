package com.dto;

import java.math.BigDecimal;

public class BillingDTO {
    private Long orderId;
    private BigDecimal amount;

    // Default constructor
    public BillingDTO() {
    }

    // Constructor with parameters
    public BillingDTO(Long orderId, BigDecimal amount) {
        this.orderId = orderId;
        this.amount = amount;
    }

    // Getter for orderId
    public Long getOrderId() {
        return orderId;
    }

    // Setter for orderId
    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    // Getter for amount
    public BigDecimal getAmount() {
        return amount;
    }

    // Setter for amount
    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }
}
