package com.dto;

import java.util.List;

public class OrderSelectionDTO {
    private Long customerId;
    private List<Long> menuItemIds;
    private String deliveryMode;

    // Default constructor
    public OrderSelectionDTO() {
    }

    // Constructor with parameters
    public OrderSelectionDTO(Long customerId, List<Long> menuItemIds, String deliveryMode) {
        this.customerId = customerId;
        this.menuItemIds = menuItemIds;
        this.deliveryMode = deliveryMode;
    }

    // Getter for customerId
    public Long getCustomerId() {
        return customerId;
    }

    // Setter for customerId
    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    // Getter for menuItemIds
    public List<Long> getMenuItemIds() {
        return menuItemIds;
    }

    // Setter for menuItemIds
    public void setMenuItemIds(List<Long> menuItemIds) {
        this.menuItemIds = menuItemIds;
    }

    // Getter for deliveryMode
    public String getDeliveryMode() {
        return deliveryMode;
    }

    // Setter for deliveryMode
    public void setDeliveryMode(String deliveryMode) {
        this.deliveryMode = deliveryMode;
    }
}
