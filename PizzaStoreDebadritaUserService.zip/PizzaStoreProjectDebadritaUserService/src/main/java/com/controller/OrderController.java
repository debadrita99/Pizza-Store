package com.controller;

import java.awt.MenuItem;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import com.entity.Order;
import com.service.OrderServiceImpl;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

    @Autowired
    private OrderServiceImpl orderService;
    
    @Autowired
    RestTemplate restTemplate;
   
    @GetMapping("/getmenuitems")
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<List<MenuItem>>getMenuItems(){
     String url="http://localhost:9090/menu/getitems";
        MenuItem[] itemsArray = restTemplate.getForObject(url, MenuItem[].class);    
         // Convert the array to a List
         List<MenuItem> itemsList = Arrays.asList(itemsArray);
         return new ResponseEntity<>(itemsList, HttpStatus.OK);
    }

    // POST: Create a new order
    @PostMapping("/create")
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<Order> createOrder(@RequestBody Order order) {
        Order newOrder = orderService.saveOrder(order);
        return new ResponseEntity<>(newOrder, HttpStatus.CREATED);
    }

    // GET: Retrieve an order by ID
    @GetMapping("/details/{orderid}")
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<Order> getOrderDetails(@PathVariable Long orderid) {
        return orderService.findOrderById(orderid)
            .map(order -> new ResponseEntity<>(order, HttpStatus.OK))
            .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    // PUT: Update an order by ID
    @PutMapping("/update/{orderid}")
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<Order> updateOrder(@PathVariable Long orderid, @RequestBody Order orderDetails) {
        return orderService.findOrderById(orderid)
            .map(existingOrder -> {
                existingOrder.setOrderName(orderDetails.getOrderName());
                existingOrder.setOrderPrice(orderDetails.getOrderPrice());
                existingOrder.setUser(orderDetails.getUser()); // Update user reference if needed
                Order updatedOrder = orderService.saveOrder(existingOrder);
                return new ResponseEntity<>(updatedOrder, HttpStatus.OK);
            })
            .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    // DELETE: Delete an order by ID
    @DeleteMapping("/remove/{orderid}")
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<Void> deleteOrder(@PathVariable Long orderid) {
        if (orderService.findOrderById(orderid).isPresent()) {
            orderService.deleteOrder(orderid);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}

